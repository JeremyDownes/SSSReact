import React from 'react' 

class Footer extends React.Component {
	render() {
		return (
		  <footer>
  			<p>© 2017 Sunshine State Software LLC. All rights reserved</p>
  		</footer>
		)
	}
}

export default Footer